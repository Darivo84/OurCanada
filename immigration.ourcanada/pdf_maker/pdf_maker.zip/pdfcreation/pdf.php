<body>
	<header style="background-image:url('images/bg.jpg');display: -moz-flex;display: -webkit-flex;display: -ms-flex;display: flex;flex-direction: column;align-items: flex-end;justify-content: space-between;background-color:#1f1815;background-attachment: scroll, scroll;background-position: top left, top left;background-repeat: repeat, no-repeat;background-size: auto, 150%;color:rgba(255, 255, 255, 0.5);height: 100%;left: 0;padding: 8em 4em;position: fixed;text-align: right;top: 0;width: 35%;">
		<div class="inner">
			
		</div>
	</header>
	<div id="main" style="margin-left: 35%; max-width: 54em; padding: 8em 4em 4em 4em; width: calc(100% - 35%)">
		<h2>Organizational Information</h2>
	</div>
</body>